# DDos
# Realiza un ataque de ddos desde termux
# con DDos.py 
![screenshot_20190204-142513 01](https://user-images.githubusercontent.com/46208706/52235098-ca86b580-2888-11e9-90a1-f66e1443bf59.png)

# envia archivos basura a pajinas
![screenshot_20190204-142701](https://user-images.githubusercontent.com/46208706/52235201-0f125100-2889-11e9-8795-2104e4594a39.png)

# contactame
# https://t.me/CesarGray
# suscribete a mi cana
# https://www.youtube.com/channel/UCjs0N8PbEo-se0r_4O_svNQ
# al darle git clone al enlase de ddos dale bash requisitos.sh se encarga de instalar todo saludos att.. César
